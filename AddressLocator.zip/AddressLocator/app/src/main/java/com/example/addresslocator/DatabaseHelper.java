package com.example.addresslocator;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "addresses_db.db";
    public static final String TABLE_NAME = "address_table";

    public static final String ID = "ID";
    public static final String COL_1 = "ADDRESS";
    public static final String COL_2 = "LATITUDE";
    public static final String COL_3 = "LONGITUDE";

    public DatabaseHelper(@Nullable FragmentActivity context) {
        super(context, DATABASE_NAME, null, 1);
        //SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_NAME + " ("
                + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_1 + " TEXT, "
                + COL_2 + " TEXT, "
                + COL_3 + " TEXT "
                +")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        onCreate(sqLiteDatabase);
    }

    public boolean insertData(String address, double lat, double lng) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1, address);
        contentValues.put(COL_2, Double.toString(lat));
        contentValues.put(COL_3, Double.toString(lng));
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }
    public boolean updateData(int id, String address, double lat, double lng) {
        String id_string = String.valueOf(id);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1, address);
        contentValues.put(COL_2, Double.toString(lat));
        contentValues.put(COL_3, Double.toString(lng));
        long result = db.update(TABLE_NAME,contentValues, "ID=?", new String[]{id_string});
        return result != -1;
    }
    public boolean deleteData(int id) {
        String id_string = String.valueOf(id);
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME,"ID=?", new String[]{id_string});
        return result != -1;
    }

    public Cursor getData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        return res;
    }
}

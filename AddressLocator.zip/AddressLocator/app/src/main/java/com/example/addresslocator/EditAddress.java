package com.example.addresslocator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditAddress extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_address);

        Intent prevIntent = getIntent();

        int id = prevIntent.getIntExtra("id", 0);
        String address = prevIntent.getStringExtra("address");
        double lat = prevIntent.getDoubleExtra("lat", 0);
        double lng = prevIntent.getDoubleExtra("lng", 0);
//        Toast.makeText(this, Double.toString(lat), Toast.LENGTH_SHORT).show();

        DatabaseHelper db = new DatabaseHelper(this);

        EditText addressName = (EditText) findViewById(R.id.addressName2);
        EditText lat_text = (EditText) findViewById(R.id.lat2);
        EditText lng_text = (EditText) findViewById(R.id.lng2);

        addressName.setText(address);
        lat_text.setText(Double.toString(lat));
        lng_text.setText(Double.toString(lng));

        Button save = (Button) findViewById(R.id.saveButton);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (addressName.getText().toString().equals("") || lat_text.getText().toString().equals("") || lng_text.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Please make sure to fill out all fields! ", Toast.LENGTH_SHORT).show();
                } else {

                    String address = addressName.getText().toString();
                    double lat = Double.parseDouble(lat_text.getText().toString());
                    double lng = Double.parseDouble(lng_text.getText().toString());

                    boolean updated = db.updateData(id, address, lat, lng);

                    if (updated) {
                        Toast.makeText(getApplicationContext(), "Updated address! ", Toast.LENGTH_SHORT).show();
                        
                        finish();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Failed to update address! ", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });

    }

}
package com.example.addresslocator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;
    ArrayList<Address> addresses = new ArrayList<Address>();
    SearchView searchView;
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchView = (SearchView) findViewById(R.id.searchAddress);
        db = new DatabaseHelper(this);
        setupData();

//        Intent x = new Intent(MainActivity.this, GeocoderActivity.class);
//        startActivity(x);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                ArrayList<Address> filteredAddresses = new ArrayList<Address>();

                for (Address address : addresses) {
                    if (address.address.toLowerCase().contains(s.toLowerCase())) filteredAddresses.add(address);
                }
                AddressAdapter adapter = new AddressAdapter(getApplicationContext(), 0, filteredAddresses);
                listView.setAdapter(adapter);

                return false;
            }
        });

        FloatingActionButton addButton = (FloatingActionButton) findViewById(R.id.openAdd);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent openAdd = new Intent(getApplicationContext(), AddAddress.class);
                startActivity(openAdd);
            }
        });


    }

    public void setupData() {
        addresses.clear();
        Cursor res = db.getData();
        if(res.getCount() > 0) {
            while (res.moveToNext()) {
                @SuppressLint("Range") int id = (int)res.getLong(res.getColumnIndex("ID"));
//                int id = 0;
                Address line = new Address(id, res.getString(1), Double.parseDouble(res.getString(2)), Double.parseDouble(res.getString(3)));
                addresses.add(line);
            }
            setupList();
        }
    }

    public void setupList() {
        listView = (ListView) findViewById(R.id.addressList);
        AddressAdapter adapter = new AddressAdapter(this, 0, addresses);
        listView.setAdapter(adapter);
    }
}
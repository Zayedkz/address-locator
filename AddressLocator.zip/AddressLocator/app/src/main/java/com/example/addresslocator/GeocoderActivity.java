package com.example.addresslocator;

import androidx.appcompat.app.AppCompatActivity;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class GeocoderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_geocoder);


        double[] number1 = randomGeo(43.651070, -79.347015, 1000);
        Geocoder geocoder;
        geocoder = new Geocoder(this, Locale.getDefault());

        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocation(43.907320, -78.980380, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Toast.makeText(getApplicationContext(), Boolean.toString(geocoder.isPresent()), Toast.LENGTH_SHORT).show();

    }
    private double[] randomGeo(double latitude, double longitude, double radius) {
        double y0 = latitude;
        double x0 = longitude;
        double rd = radius / 111300;

        double u = Math.random();
        double v = Math.random();

        double w = rd * Math.sqrt(u);
        double t = 2 * Math.PI * v;
        double x = w * Math.cos(t);
        double y = w * Math.sin(t);

        double[] value = {
                y + y0, // 'latitude':
                x + x0 //'longitude':
        };

        return value;
    }
}
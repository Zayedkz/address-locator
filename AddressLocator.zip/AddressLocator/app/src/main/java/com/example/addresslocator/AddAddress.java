package com.example.addresslocator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class AddAddress extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_address);

        Button add1 = (Button) findViewById(R.id.addButton);

        DatabaseHelper db = new DatabaseHelper(this);

        add1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText addressName = (EditText) findViewById(R.id.addressName);
                EditText lat_text = (EditText) findViewById(R.id.lat);
                EditText lng_text = (EditText) findViewById(R.id.lng);

                if (addressName.getText().toString().equals("") || lat_text.getText().toString().equals("") || lng_text.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Please make sure to fill out all fields! ", Toast.LENGTH_SHORT).show();
                } else {

                    String address = addressName.getText().toString();
                    double lat = Double.parseDouble(lat_text.getText().toString());
                    double lng = Double.parseDouble(lng_text.getText().toString());

                    boolean added = db.insertData(address, lat, lng);

                    if (added) {
                        Toast.makeText(getApplicationContext(), "Added new address! ", Toast.LENGTH_SHORT).show();

                        finish();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Failed to add new address! ", Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });
    }
}
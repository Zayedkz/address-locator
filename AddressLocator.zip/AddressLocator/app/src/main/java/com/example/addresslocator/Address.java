package com.example.addresslocator;

public class Address {

    public int id;
    public String address;
    public double lat;
    public double lng;

    public Address(int id, String address, double lat, double lng) {
        this.id = id;
        this.address = address;
        this.lat = lat;
        this.lng = lng;
    }


}

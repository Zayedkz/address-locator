package com.example.addresslocator;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

import java.util.List;

public class AddressAdapter extends ArrayAdapter<Address> {

    public AddressAdapter(Context context, int resource, List<Address> addressList) {
        super(context, resource, addressList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        Address address = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.address_cell, parent, false);
        }
        TextView address_name = (TextView) convertView.findViewById(R.id.address);
        ImageButton edit = (ImageButton) convertView.findViewById(R.id.editButton);
        ImageButton delete = (ImageButton) convertView.findViewById(R.id.deleteButton);
        address_name.setText(address.address);

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent editDetails = new Intent(getContext(), EditAddress.class);
                editDetails.putExtra("id", address.id);
                editDetails.putExtra("address", address.address);
                editDetails.putExtra("lat", address.lat);
                editDetails.putExtra("lng", address.lng);
                getContext().startActivity(editDetails);
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseHelper db = new DatabaseHelper((FragmentActivity) getContext());
                db.deleteData(address.id);
                remove(address);
            }
        });

        return convertView;
    }
}
